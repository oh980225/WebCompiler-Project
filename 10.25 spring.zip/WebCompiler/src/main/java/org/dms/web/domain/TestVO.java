package org.dms.web.domain;

public class TestVO {
	private String problem_level;
	private String category_name;
	
	public String getLevel() {
		return problem_level;
	}
	public void setLevel(String problem_level) {
		this.problem_level = problem_level;
	}
	public String getName() {
		return category_name;
	}
	public void setName(String category_name) {
		this.category_name = category_name;
	}
}
